#!/bin/bash
export UUID=${UUID:-'0927f767-f333-9696-7be9-5fa0cb79a51e'}
export NAME=${NAME:-'Java'}
export FILE_PATH=${FILE_PATH:-'./world'}
export REALITY_PORT=${REALITY_PORT:-''} # 默认开放的端口，可不填
export XHTTP_REALITY_PORT=${XHTTP_REALITY_PORT:-'25693'} #不填不启用
export SNI=${SNI:-'www.tesla.com'}
export ARGO_PORT=${ARGO_PORT:-'8881'} # 不填不启用
export ARGO_DOMAIN=${ARGO_DOMAIN:-'testmctwzzzzhst2play.okmc.kdns.fr'}
export ARGO_AUTH=${ARGO_AUTH:-'{"AccountTag":"b948f17050ea1cf9bd37a57c99ff92c9","TunnelSecret":"lEZLgAFeQmef/j3iLtgu2ZzccM674hVAEGhP7JKGreY=","TunnelID":"ad9fad74-2e72-4cdb-9b2f-6b450b062780","Endpoint":""}'}
export CFIP=${CFIP:-'time.is'}
export CFPORT=${CFPORT:-'443'}
export GAME_FILE=${GAME_FILE:-'srever.jar'}
export XRAY_AMD64_URL=${XRAY_AMD64_URL:-'https://raw.githubusercontent.com/codsandbx/xcorecfbot/main/Xry-amd-64.tar.gz'}
export XRAY_ARM64_URL=${XRAY_ARM64_URL:-'https://raw.githubusercontent.com/codsandbx/xcorecfbot/main/Xry-arm-64.tar.gz'}
export USE_OFFICIAL_FALLBACK=${USE_OFFICIAL_FALLBACK:-'true'}

UUID=$(echo "$UUID" | tr -d '[:space:]\r\n')
NAME=$(echo "$NAME" | tr -d '\r\n')
FILE_PATH=$(echo "$FILE_PATH" | tr -d '[:space:]\r\n')
REALITY_PORT=$(echo "$REALITY_PORT" | tr -d '[:space:]\r\n')
XHTTP_REALITY_PORT=$(echo "$XHTTP_REALITY_PORT" | tr -d '[:space:]\r\n')
SNI=$(echo "$SNI" | sed -e 's|^https*://||' -e 's|/.*||' | tr -d '[:space:]\r\n')
ARGO_DOMAIN=$(echo "$ARGO_DOMAIN" | tr -d '[:space:]\r\n')
ARGO_AUTH=$(echo "$ARGO_AUTH" | tr -d '[:space:]\r\n')
CFIP=$(echo "$CFIP" | tr -d '[:space:]\r\n')
CFPORT=$(echo "$CFPORT" | tr -d '[:space:]\r\n')
ARGO_PORT=$(echo "$ARGO_PORT" | tr -d '[:space:]\r\n')
GAME_FILE=$(echo "$GAME_FILE" | tr -d '[:space:]\r\n')

[ ! -d "${FILE_PATH}" ] && mkdir -p "${FILE_PATH}"
rm -rf boot.log config.json tunnel.json tunnel.yml xray.log list.txt "${FILE_PATH}/sub.txt" 2>/dev/null

echo -e "\n[INFO] 环境变量探测"
env | sort

# ===== 端口优先级：环境变量 > 顶部设定 > 兜底 =====
if [ -n "$SERVER_PORT" ]; then
    REALITY_PORT=$SERVER_PORT
    echo -e "[INFO] 使用 SERVER_PORT 作为 REALITY_PORT: $REALITY_PORT"
elif [ -n "$PORT" ]; then
    REALITY_PORT=$PORT
    echo -e "[INFO] 使用 PORT 作为 REALITY_PORT: $REALITY_PORT"
elif [ -z "$REALITY_PORT" ]; then
    REALITY_PORT=32631
    echo -e "[INFO] 使用兜底端口: $REALITY_PORT"
else
    echo -e "[INFO] 使用顶部 REALITY_PORT: $REALITY_PORT"
fi

ENABLE_VISION=true
[ -n "$XHTTP_REALITY_PORT" ] && ENABLE_XHTTP_REALITY=true || ENABLE_XHTTP_REALITY=false
[ -n "$ARGO_PORT" ] && ENABLE_ARGO=true || ENABLE_ARGO=false

echo -e "[INFO] REALITY+Vision 端口: $REALITY_PORT (始终启用)"
[ "$ENABLE_XHTTP_REALITY" = true ] && echo -e "[INFO] REALITY+XHTTP 端口: $XHTTP_REALITY_PORT (已启用)" || echo -e "[INFO] REALITY+XHTTP 未启用"
[ "$ENABLE_ARGO" = true ] && echo -e "[INFO] Argo XHTTP 端口: $ARGO_PORT (已启用)" || echo -e "[INFO] Argo 未启用"

# ===== Argo 配置 =====
argo_configure() {
  if [ "$ENABLE_ARGO" = false ]; then return; fi
  if [[ -z "$ARGO_AUTH" || -z "$ARGO_DOMAIN" ]]; then
    echo "[WARN] ARGO_AUTH 或 ARGO_DOMAIN 为空，跳过固定隧道配置"
    return
  fi
  if [[ $ARGO_AUTH =~ TunnelSecret ]]; then
    echo "$ARGO_AUTH" > tunnel.json
    cat > tunnel.yml << EOF
tunnel: $(cut -d\" -f12 <<< "$ARGO_AUTH")
credentials-file: tunnel.json
protocol: http2
ingress:
  - hostname: $ARGO_DOMAIN
    service: http://localhost:$ARGO_PORT
    originRequest:
      noTLSVerify: true
  - service: http_status:404
EOF
  fi
}

# ===== 下载与运行 =====
download_and_run() {
ARCH=$(uname -m)
DOWNLOAD_DIR="."
mkdir -p "$DOWNLOAD_DIR"
echo "[INFO] 检测到架构: $ARCH"

if [[ "$ARCH" =~ ^(arm|arm64|aarch64)$ ]]; then
    XRAY_URL="${XRAY_ARM64_URL}"
    CLOUDFLARED_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64"
    ARCH_TYPE="arm64"
elif [[ "$ARCH" =~ ^(amd64|x86_64|x86)$ ]]; then
    XRAY_URL="${XRAY_AMD64_URL}"
    CLOUDFLARED_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"
    ARCH_TYPE="amd64"
else
    echo "[ERROR] 不支持的架构: $ARCH"
    exit 1
fi

if [ "$USE_OFFICIAL_FALLBACK" = "true" ]; then
    XRAY_LATEST=$(curl -sS https://api.github.com/repos/XTLS/Xray-core/releases/latest 2>/dev/null | grep "tag_name" | head -n1 | cut -d'"' -f4)
    [ -z "$XRAY_LATEST" ] && XRAY_LATEST="v25.9.11"
    if [ "$ARCH_TYPE" = "arm64" ]; then
        XRAY_FALLBACK_URL="https://github.com/XTLS/Xray-core/releases/download/${XRAY_LATEST}/Xray-linux-arm64-v8a.zip"
    else
        XRAY_FALLBACK_URL="https://github.com/XTLS/Xray-core/releases/download/${XRAY_LATEST}/Xray-linux-64.zip"
    fi
fi

FILE_INFO=("${XRAY_URL} web" "${CLOUDFLARED_URL} bot")
declare -A FILE_MAP

generate_random_name() {
    local chars=abcdefghijklmnopqrstuvwxyz1234567890
    local name=""
    for i in {1..6}; do name="$name${chars:RANDOM%${#chars}:1}"; done
    echo "$name"
}

download_file() {
    local URL=$1 NEW_FILENAME=$2 FALLBACK_URL=$3
    echo "[INFO] 正在下载: $(basename "$URL")"
    download_success=false
    if command -v curl >/dev/null 2>&1; then
        curl -L -sS -f -o "$NEW_FILENAME.tmp" "$URL" 2>/dev/null && download_success=true
    elif command -v wget >/dev/null 2>&1; then
        wget -q -O "$NEW_FILENAME.tmp" "$URL" 2>/dev/null && download_success=true
    fi
    if [ "$download_success" = false ] && [ -n "$FALLBACK_URL" ]; then
        echo "[WARN] 主链接失败，尝试官方源..."
        if command -v curl >/dev/null 2>&1; then
            curl -L -sS -o "$NEW_FILENAME.tmp" "$FALLBACK_URL" || return 1
        else
            wget -q -O "$NEW_FILENAME.tmp" "$FALLBACK_URL" || return 1
        fi
    elif [ "$download_success" = false ]; then
        echo "[ERROR] 下载失败: $URL"
        return 1
    fi
    FILE_TYPE=$(file "$NEW_FILENAME.tmp" 2>/dev/null || echo "unknown")
    if [[ "$FILE_TYPE" == *"gzip"* || "$URL" == *.tar.gz ]]; then
        tar -xzf "$NEW_FILENAME.tmp" -C . 2>/dev/null || return 1
        [ -f "xray" ] && mv xray "$NEW_FILENAME"
        rm -f "$NEW_FILENAME.tmp" geoip.dat geosite.dat LICENSE README.md 2>/dev/null
    elif [[ "$URL" == *.zip ]]; then
        unzip -o "$NEW_FILENAME.tmp" -d . >/dev/null 2>&1
        [ -f "xray" ] && mv xray "$NEW_FILENAME"
        rm -f "$NEW_FILENAME.tmp" geoip.dat geosite.dat LICENSE README.md 2>/dev/null
    else
        mv "$NEW_FILENAME.tmp" "$NEW_FILENAME"
    fi
    return 0
}

URL=$(echo "${FILE_INFO[0]}" | cut -d' ' -f1)
RANDOM_NAME=$(generate_random_name)
NEW_FILENAME="$DOWNLOAD_DIR/$RANDOM_NAME"
download_file "$URL" "$NEW_FILENAME" "$XRAY_FALLBACK_URL" || exit 1
chmod +x "$NEW_FILENAME"
FILE_MAP[web]="$NEW_FILENAME"

if [ "$ENABLE_ARGO" = true ]; then
    URL=$(echo "${FILE_INFO[1]}" | cut -d' ' -f1)
    RANDOM_NAME=$(generate_random_name)
    NEW_FILENAME="$DOWNLOAD_DIR/$RANDOM_NAME"
    download_file "$URL" "$NEW_FILENAME" "" || exit 1
    chmod +x "$NEW_FILENAME"
    FILE_MAP[bot]="$NEW_FILENAME"
fi

# Reality 密钥
if [ -f "reality_keys.txt" ]; then
    private_key=$(awk -F': ' '/Private key/ {print $2}' reality_keys.txt | tr -d ' \r\n')
    public_key=$(awk -F': ' '/Public key/ {print $2}' reality_keys.txt | tr -d ' \r\n')
    short_id=$(awk -F': ' '/ShortID/ {print $2}' reality_keys.txt | tr -d ' \r\n')
fi

validate_key() {
    [[ "$1" =~ ^[A-Za-z0-9+/_-]{43,44}$ ]]
}

if ! validate_key "$private_key" || ! validate_key "$public_key" || [ -z "$short_id" ]; then
    echo "[INFO] 生成新 Reality 密钥..."
    if [ -e "${FILE_MAP[web]}" ]; then
        ./"${FILE_MAP[web]}" x25519 > /tmp/xray_keys.txt 2>&1
        private_key=$(grep -i private /tmp/xray_keys.txt | sed 's/.*: *//' | tr -d ' \r\n')
        public_key=$(grep -i public /tmp/xray_keys.txt | sed 's/.*: *//' | tr -d ' \r\n')
        [ -z "$private_key" ] && private_key=$(sed -n '1p' /tmp/xray_keys.txt | awk '{print $NF}' | tr -d ' \r\n')
        [ -z "$public_key" ] && public_key=$(sed -n '2p' /tmp/xray_keys.txt | awk '{print $NF}' | tr -d ' \r\n')
        rm -f /tmp/xray_keys.txt
    fi
    if ! validate_key "$private_key" || ! validate_key "$public_key"; then
        echo "[ERROR] 密钥生成失败"
        exit 1
    fi
    short_id=$(openssl rand -hex 8 | tr -d '\r\n ')
    cat > reality_keys.txt << EOF
Private key: $private_key
Public key: $public_key
ShortID: $short_id
EOF
fi

argo_configure
wait

# 动态拼接 inbounds
INBOUNDS=""

# 1. 主力：REALITY + TCP + Vision（始终启用）
INBOUNDS=$(cat << EOF
    {
      "tag": "vless-reality-vision",
      "port": ${REALITY_PORT},
      "listen": "::",
      "protocol": "vless",
      "settings": {
        "clients": [
          {
            "id": "${UUID}",
            "flow": "xtls-rprx-vision"
          }
        ],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "raw",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "${SNI}:443",
          "xver": 0,
          "serverNames": ["${SNI}"],
          "privateKey": "${private_key}",
          "shortIds": ["${short_id}"]
        }
      },
      "sniffing": {
        "enabled": true,
        "destOverride": ["http", "tls", "quic"]
      }
    }
EOF
)

# 2. 可选：REALITY + XHTTP
if [ "$ENABLE_XHTTP_REALITY" = true ]; then
INBOUNDS="${INBOUNDS},
    {
      \"tag\": \"vless-reality-xhttp\",
      \"port\": ${XHTTP_REALITY_PORT},
      \"listen\": \"::\",
      \"protocol\": \"vless\",
      \"settings\": {
        \"clients\": [{\"id\": \"${UUID}\", \"flow\": \"\"}],
        \"decryption\": \"none\"
      },
      \"streamSettings\": {
        \"network\": \"xhttp\",
        \"security\": \"reality\",
        \"realitySettings\": {
          \"show\": false,
          \"dest\": \"${SNI}:443\",
          \"xver\": 0,
          \"serverNames\": [\"${SNI}\"],
          \"privateKey\": \"${private_key}\",
          \"shortIds\": [\"${short_id}\"]
        },
        \"xhttpSettings\": {
          \"path\": \"/realthispath-vls-xhp\",
          \"host\": \"${SNI}\",
          \"mode\": \"auto\"
        }
      },
      \"sniffing\": {
        \"enabled\": true,
        \"destOverride\": [\"http\", \"tls\", \"quic\"]
      }
    }"
fi

# 3. 可选：Argo VLESS + XHTTP
if [ "$ENABLE_ARGO" = true ]; then
INBOUNDS="${INBOUNDS},
    {
      \"tag\": \"vless-xhttp-argo\",
      \"port\": ${ARGO_PORT},
      \"listen\": \"127.0.0.1\",
      \"protocol\": \"vless\",
      \"settings\": {
        \"clients\": [{\"id\": \"${UUID}\"}],
        \"decryption\": \"none\"
      },
      \"streamSettings\": {
        \"network\": \"xhttp\",
        \"security\": \"none\",
        \"xhttpSettings\": {
          \"path\": \"/vlstothistpathing\",
          \"mode\": \"auto\"
        }
      },
      \"sniffing\": {
        \"enabled\": true,
        \"destOverride\": [\"http\", \"tls\", \"quic\"]
      }
    }"
fi

cat > config.json << EOF
{
  "log": {
    "loglevel": "info"
  },
  "inbounds": [
${INBOUNDS}
  ],
  "outbounds": [
    {
      "protocol": "freedom",
      "tag": "direct"
    }
  ]
}
EOF

if [ -e "${FILE_MAP[web]}" ]; then
    nohup ./"${FILE_MAP[web]}" run -c config.json > xray.log 2>&1 &
    sleep 3
fi

if [ "$ENABLE_ARGO" = true ] && [ -e "${FILE_MAP[bot]}" ]; then
    if [[ $ARGO_AUTH =~ ^[A-Z0-9a-z=]{120,250}$ ]]; then
      args="tunnel --edge-ip-version auto --no-autoupdate --protocol http2 run --token ${ARGO_AUTH}"
    elif [[ $ARGO_AUTH =~ TunnelSecret ]]; then
      args="tunnel --edge-ip-version auto --config tunnel.yml run"
    else
      args="tunnel --edge-ip-version auto --no-autoupdate --protocol http2 --logfile boot.log --loglevel info --url http://localhost:$ARGO_PORT"
    fi
    nohup ./"${FILE_MAP[bot]}" $args >/dev/null 2>&1 &
    sleep 2
fi

sleep 1
rm -f "${FILE_MAP[web]}"
[ "$ENABLE_ARGO" = true ] && rm -f "${FILE_MAP[bot]}"
}

download_and_run

# ===== 获取 Argo 域名 =====
get_argodomain() {
  if [ "$ENABLE_ARGO" = false ]; then
    echo ""
    return
  fi
  if [[ -n "$ARGO_AUTH" ]]; then
    echo "$ARGO_DOMAIN"
  else
    local retry=0
    local max_retries=8
    local argodomain=""
    while [[ $retry -lt $max_retries ]]; do
      ((retry++))
      argodomain=$(grep -oE 'https://[[:alnum:]+\.-]+\.trycloudflare\.com' boot.log 2>/dev/null | head -n1 | sed 's@https://@@' | tr -d ' \r\n')
      [ -n "$argodomain" ] && break
      sleep 1
    done
    echo "$argodomain"
  fi
}

argodomain=$(get_argodomain)
sleep 1

# ===== 获取 IP 与 ISP 信息 =====
IP=$(curl -s --max-time 2 ipv4.ip.sb 2>/dev/null || curl -s --max-time 2 api.ipify.org 2>/dev/null || echo "未知IP")
META=$(curl -4 -s --max-time 5 https://ipinfo.io/json 2>/dev/null)
COUNTRY=$(echo "$META" | sed -n 's/.*"country":[ ]*"\([^"]*\)".*/\1/p')
ISP_ORG=$(echo "$META" | sed -n 's/.*"org":[ ]*"\([^"]*\)".*/\1/p')
if [ -z "$COUNTRY" ] || [ -z "$ISP_ORG" ]; then
    META=$(curl -4 -s --max-time 5 https://ipapi.co/json 2>/dev/null)
    COUNTRY=$(echo "$META" | sed -n 's/.*"country":[ ]*"\([^"]*\)".*/\1/p')
    ISP_ORG=$(echo "$META" | sed -n 's/.*"org":[ ]*"\([^"]*\)".*/\1/p')
fi
[ -z "$COUNTRY" ] && COUNTRY="US"
[ -z "$ISP_ORG" ] && ISP_ORG="Cloud"
ISP_ORG=$(echo "$ISP_ORG" | sed 's/^AS[0-9]*[ _]*//' | sed 's/,//g' | sed 's/ /_/g')
ISP="${COUNTRY}-${ISP_ORG}"

# ===== 生成订阅链接 =====
> list.txt

# 1. REALITY + Vision（始终有）
echo "vless://${UUID}@${IP}:${REALITY_PORT}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${SNI}&fp=chrome&pbk=${public_key}&sid=${short_id}&type=tcp#${NAME}-Reality-Vision-${ISP}" >> list.txt

# 2. REALITY + XHTTP（可选）
if [ "$ENABLE_XHTTP_REALITY" = true ]; then
  echo "vless://${UUID}@${IP}:${XHTTP_REALITY_PORT}?encryption=none&flow=&security=reality&sni=${SNI}&fp=chrome&pbk=${public_key}&sid=${short_id}&type=xhttp&path=%2Frealthispath-vls-xhp&host=${SNI}&mode=auto#${NAME}-Reality-XHTTP-${ISP}" >> list.txt
fi

# 3. Argo VLESS + XHTTP（可选）
if [ "$ENABLE_ARGO" = true ] && [ -n "$argodomain" ]; then
  echo "vless://${UUID}@${CFIP}:${CFPORT}?encryption=none&security=tls&sni=${argodomain}&type=xhttp&host=${argodomain}&path=%2Fvlstothistpathing&mode=packet-up#${NAME}-Argo-XHTTP-${ISP}" >> list.txt
fi

base64 -w0 list.txt > "${FILE_PATH}/sub.txt"

echo -e "\n\e[1;36m=============== 代理服务状态核验 ===============\e[0m"
if ss -nltp 2>/dev/null | grep -q ":$REALITY_PORT " || netstat -nltp 2>/dev/null | grep -q ":$REALITY_PORT "; then
    echo -e "\e[1;32m[OK] Xray 已启动，REALITY 端口 $REALITY_PORT 正在监听\e[0m"
else
    echo -e "\e[1;31m[ERROR] Xray 未能监听端口 $REALITY_PORT，请查看日志：\e[0m"
    tail -n 30 xray.log 2>/dev/null
fi
echo -e "\e[1;36m================================================\e[0m\n"

[ "$ENABLE_ARGO" = true ] && echo -e "\e[1;32mArgoDomain:\e[1;35m${argodomain}\e[0m"
echo -e "\n订阅内容："
cat "${FILE_PATH}/sub.txt"
echo -e "\n\e[1;32m${FILE_PATH}/sub.txt 已保存\e[0m"
echo -e "\e[1;32mRunning done!\e[0m\n"

sleep 6
clear
rm -rf boot.log config.json xray.log list.txt core 2>/dev/null
chmod +x "${GAME_FILE}" 2>/dev/null

[ -f "${GAME_FILE}" ] && java -Xms128M -XX:MaxRAMPercentage=75.0 -jar "${GAME_FILE}"

tail -f /dev/null